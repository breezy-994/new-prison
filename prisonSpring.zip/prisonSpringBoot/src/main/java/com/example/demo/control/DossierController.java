package com.example.demo.control;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Dossier;
import com.example.demo.entity.Guard;
import com.example.demo.entity.Prisoners;
import com.example.demo.exception.NotFoundException;
import com.example.demo.service.DossierService;
import com.example.demo.service.GuardService;
import com.example.demo.service.PrisonerService;

@RestController
@RequestMapping("/dossier")
@CrossOrigin(origins="http://localhost:4200")
public class DossierController {

	@Autowired
	private DossierService dossierService;
	
	@Autowired
	private PrisonerService prisonerService;
	

	@Autowired
	private GuardService guardService;
	
	@GetMapping(value="/getDossierById",produces="application/json")
	public ResponseEntity<Dossier> getDossier(@RequestParam(value="id")Integer id){
		return new ResponseEntity<Dossier>(this.dossierService.foundById(id),HttpStatus.OK);
	}
	
	
	@GetMapping(value="/allDossiers",produces="application/json")
	public ResponseEntity<List<Dossier>> getDossiers(){
		return new ResponseEntity<List<Dossier>>(this.dossierService.getAllDossiers(),HttpStatus.OK);
	}
	
	@PostMapping(value="/inserisci",produces="application/json",consumes="application/json")
	public ResponseEntity<Dossier> insertDossier(@RequestBody Dossier dossier){
		//Gestisco meglio con un DossierDTO
		System.out.println(dossier.toString());
		return new ResponseEntity<Dossier>(this.dossierService.inserisci(dossier),HttpStatus.OK);
	}

	@PostMapping(value="/update",produces="application/json",consumes="application/json")
	public ResponseEntity<Dossier> updateDossier(@RequestBody Dossier dossier) throws NotFoundException{
		Dossier upd=this.dossierService.foundById(dossier.getId());
		if(upd==null) {
			throw new NotFoundException("dossier non trovato");
		}
		upd.setCrimine(dossier.getCrimine());
		upd.setDataCarcerazione(dossier.getDataScarcerazione());
		upd.setDataScarcerazione(dossier.getDataScarcerazione());
		this.dossierService.update(upd);
		return new ResponseEntity<Dossier>(upd,HttpStatus.OK);
	}

	@DeleteMapping(value="/delete",produces="application/json")
	public ResponseEntity<Dossier> deleteDossier(@RequestParam(value="id") Integer id) throws NotFoundException{
		Dossier dossier=this.dossierService.foundById(id);
		if(dossier==null) {
			throw new NotFoundException("Dossier non trovato!");
		}
		System.out.println("elimino "+id);
		return new ResponseEntity<Dossier>(this.dossierService.delete(dossier),HttpStatus.OK);
	}

	@GetMapping(value="/ricercaPerCrimine",produces="application/json")
	public ResponseEntity<List<Dossier>> ricercaDossierPerCrimine(@RequestParam(value="crimine")String crimine){
		System.out.println(this.dossierService.ricercaPerCrimine(crimine).size());
		return new ResponseEntity<List<Dossier>>(this.dossierService.ricercaPerCrimine(crimine),HttpStatus.OK);
	}
	
	@GetMapping(value="/ricercaPerPrisonerCf",produces="application/json")
	public ResponseEntity<List<Dossier>> ricercaPerPrisonerCf(@RequestParam(value="cf")String cf) throws NotFoundException{
	
		Dossier d=this.dossierService.ricercaPerPrisonerCf(cf);
		if(d==null) {
			throw new NotFoundException("Dossier non trovato!");
			
		}
		List <Dossier> dossier=new ArrayList<Dossier>();
		dossier.add(d);
		return new ResponseEntity<List<Dossier>>(dossier,HttpStatus.OK);
	}
	
	
	@PostMapping("/aggiungiGuardia")
	public ResponseEntity<Dossier> aggiungiGuardia(@RequestParam(value="id")Integer id_dossier,@RequestBody Guard guardia) throws NotFoundException{
		 Dossier dossier=this.dossierService.foundById(id_dossier);
		if(dossier==null) {
			throw new NotFoundException("Dossier non trovato!");
		}
		Guard g=this.guardService.foundById(guardia.getId());
		if(g==null) { 
			Guard ng=new Guard();
			ng.setCF(guardia.getCF());
			ng.setCognome(guardia.getCognome());
			ng.setNome(guardia.getNome());
			g=this.guardService.inserisci(ng);
		}
		dossier.setGuard(g);
		return new ResponseEntity<Dossier>(
				this.dossierService.update(dossier),HttpStatus.OK);
	}
	
	@DeleteMapping("/deletePrisoner")
	public ResponseEntity<Dossier> deletePrisoner(@RequestParam(value="id")Integer id_dossier) throws NotFoundException{
		 Dossier dossier=this.dossierService.foundById(id_dossier);
		if(dossier==null) {
			throw new NotFoundException("Dossier non trovato!");
		
		}
		Guard g = dossier.getGuard();
		if(g==null) { 
			throw new NotFoundException("Guard non trovato!");
		}
		this.guardService.delete(g);
		dossier.setGuard(null);
		return new ResponseEntity<Dossier>(this.dossierService.update(dossier),HttpStatus.OK);
	}
	
	@PostMapping("/aggiungiPrisoner")
	public ResponseEntity<Dossier> aggiungiPrisoner(@RequestParam(value="id")Integer id_dossier,@RequestBody Prisoners prisoner) throws NotFoundException{
		 Dossier dossier=this.dossierService.foundById(id_dossier);
		if(dossier==null) {
			throw new NotFoundException("Dossier non trovato!");
		}
		Prisoners p=this.prisonerService.foundById(prisoner.getId());
		if(p==null) { 
			Prisoners np=new Prisoners();
			np.setCF(prisoner.getCF());
			np.setCognome(prisoner.getCognome());
			np.setNome(prisoner.getNome());
			p=this.prisonerService.inserisci(np);
		}
		dossier.setPrisoner(p);
		return new ResponseEntity<Dossier>(
				this.dossierService.update(dossier),HttpStatus.OK);
	}
	
	@GetMapping(value="/aggiungiPrisonerEsistente",produces="application/json")
	public ResponseEntity<Dossier> ricercaDossierPerCrimine(@RequestParam(value="id_dossier")Integer id_dossier,@RequestParam(value="id_prisoner")Integer id_prisoner) throws NotFoundException{
		Dossier dossier=this.dossierService.foundById(id_dossier);
		if(dossier==null) {
			throw new NotFoundException("Dossier non trovato!");
		}
		Prisoners prisoner=this.prisonerService.foundById(id_prisoner);
		if(prisoner==null) {
			throw new NotFoundException("Prisoner non trovato!");
		}
		dossier.setPrisoner(prisoner);
		return new ResponseEntity<Dossier>(this.dossierService.update(dossier),HttpStatus.OK);
	}
	
	@PostMapping(value="/aggiungiDossierWithIdGuardIdPrisoner",produces="application/json",consumes="application/json")
	public ResponseEntity<Dossier> insertDossierWithGuard(@RequestParam(value="id_guard") Integer id_guard, @RequestParam(value="id_prisoner") Integer id_prisoner, @RequestBody Dossier dossier) throws NotFoundException{
		Prisoners prisoner=this.prisonerService.foundById(id_prisoner);
		if(prisoner==null) {
			throw new NotFoundException("Dossier non trovato!");
		}
		Guard guard=this.guardService.foundById(id_guard);
		if(guard==null) {
			throw new NotFoundException("Dossier non trovato!");
		}
		
		dossier.setGuard(guard);
		dossier.setPrisoner(prisoner);
		
		return new ResponseEntity<Dossier>(this.dossierService.inserisci(dossier),HttpStatus.OK);
	}


}
