package com.example.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Prisoners;
import com.example.demo.repositary.PrisonerRepository;

@Service
public class PrisonerService {

	@Autowired
	private PrisonerRepository prisonerRepository;
	
	public List<Prisoners> getAllPrisoners(){
		return this.prisonerRepository.allPrisoner();
	}

	public Prisoners inserisci(Prisoners p) {
		return this.prisonerRepository.insert(p);
	}
	
	public Prisoners update(Prisoners p) {
		return this.prisonerRepository.updatePrisoner(p);
	}
	
	public Prisoners delete(Prisoners p) {
		return this.prisonerRepository.deletePrisoner(p);
	}
	
	public Prisoners foundById(Integer id) {
		return this.prisonerRepository.foundById(id);
	}
	
	public Prisoners findByCF(String cf) {
		return this.prisonerRepository.foundByCF(cf);
	}
}
