package com.example.demo.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="Guard")
public class Guard implements Serializable {
	private static final long serialVersionUID = 8137610819462181965L;

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@NotNull(message="{NotNull.Guard.id.Validation}")
	@Column(name="id_guard")
	private Integer id;
	private String nome;
	private String cognome;
	private String cf;

	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="gard")
	@JsonIgnore
	private Set<Dossier> dossiers;
	
	
	public Guard() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCF() {
		return this.cf;
	}
	public void setCF(String cF) {
		this.cf = cF;
	}

	public Set<Dossier> getDossiers() {
		return dossiers;
	}
	public void setDossier(Set<Dossier> dossier) {
		this.dossiers = dossier;
	}
	
}
