package com.example.demo.exception;

public class BindingException extends Exception {

	public BindingException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BindingException(String Messaggio)
	{
		super(Messaggio);
		this.messaggio = Messaggio;
	}

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2947817831019616019L;
	/**
	 * 
	 */
	
	private String messaggio = "Binding non andato a buon fine!";

	public String getMessaggio() {
		return messaggio;
	}

	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}
	
	
}
