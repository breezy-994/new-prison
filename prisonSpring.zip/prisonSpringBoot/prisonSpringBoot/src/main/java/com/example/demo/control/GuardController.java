package com.example.demo.control;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Dossier;
import com.example.demo.entity.Guard;
import com.example.demo.entity.Prisoners;
import com.example.demo.exception.BindingException;
import com.example.demo.exception.NotFoundException;
import com.example.demo.service.DossierService;
import com.example.demo.service.GuardService;
import com.example.demo.service.PrisonerService;

@RestController
@RequestMapping("/guard")
@CrossOrigin(origins="http://localhost:4200")
public class GuardController {

	@Autowired
	private GuardService guardService;
	

	@Autowired
	private DossierService dossierService;
	
	@GetMapping(value="/getGuardById",produces="application/json")
	public ResponseEntity<Guard> getGuard(@RequestParam(value="id")Integer id){
		return new ResponseEntity<Guard>(this.guardService.foundById(id),HttpStatus.OK);
	}
	
	
	@GetMapping("/allGuards")
	public ResponseEntity<List<Guard>> getGuards(){
		return new ResponseEntity<List<Guard>>(this.guardService.getAllGuards(),HttpStatus.OK);
	}

	@PostMapping("/inserisci")
	public ResponseEntity<Guard> insertGuard(@RequestBody Guard guard){
		return new ResponseEntity<Guard>(this.guardService.inserisci(guard),HttpStatus.OK);
	}

	@PostMapping("/update")
	public ResponseEntity<Guard> updateGuard(@RequestBody Guard guard){
		return new ResponseEntity<Guard>(this.guardService.update(guard),HttpStatus.OK);
	}

	@DeleteMapping("/delete")
	public ResponseEntity<Guard> deleteGuard(@RequestParam(value="id") Integer id){
		Guard guard=this.guardService.foundById(id);
		if(guard==null) {
			return null;
		}
		return new ResponseEntity<Guard>(this.guardService.delete(guard),HttpStatus.OK);
	}

	@PostMapping("/aggiungiDossier")
	public ResponseEntity<Dossier> aggiungiDossier(@RequestParam(value="id")Integer id_guard,@RequestBody Dossier dossier){
		Guard guard=this.guardService.foundById(id_guard);
		if(guard==null) {
			return null;
		}
		Dossier dos=this.dossierService.foundById(dossier.getId());
		if(dos==null) { 
			Dossier nd=new Dossier();
			nd.setCrimine(dossier.getCrimine());
			nd.setDataCarcerazione(dossier.getDataCarcerazione());
			nd.setGuard(guard);
			dos=this.dossierService.inserisci(nd);
		}
		Set<Dossier> dossiers=guard.getDossiers();
		dossiers.add(dos);
		guard.setDossier(dossiers);
		this.guardService.update(guard);
		return new ResponseEntity<Dossier>(dos,HttpStatus.OK);
	}
}


