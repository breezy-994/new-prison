package com.example.demo.control;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.validation.Valid;

import com.example.demo.dto.PrisonerDTO;
import com.example.demo.entity.Dossier;
import com.example.demo.entity.Guard;
import com.example.demo.entity.Prisoners;
import com.example.demo.exception.BindingException;
import com.example.demo.exception.NotFoundException;
import com.example.demo.service.DossierService;
import com.example.demo.service.PrisonerService;

@RestController
@RequestMapping("/prisoners")
@CrossOrigin(origins="http://localhost:4200")
public class PrisonerController
{

	@Autowired
	private PrisonerService prisonerService;
	
	@Autowired DossierService dossierService;
	
	@GetMapping(value="/getPrisonerById",produces="application/json")
	public ResponseEntity<Prisoners> getPrisoner(@RequestParam(value="id")Integer id){
		return new ResponseEntity<Prisoners>(this.prisonerService.foundById(id),HttpStatus.OK);
	}
	
	@GetMapping("/allPrisoners")
	public ResponseEntity<List<Prisoners>> getPrisoners(){
		return new ResponseEntity<List<Prisoners>>(this.prisonerService.getAllPrisoners(),HttpStatus.OK);
	}

	@PostMapping("/inserisci")
	public ResponseEntity<Prisoners> insertPrisoner(@RequestBody Prisoners prisoner){
		System.out.println(prisoner.toString());
		return new ResponseEntity<Prisoners>(this.prisonerService.inserisci(prisoner),HttpStatus.OK);
	}

	@PostMapping("/update")
	public ResponseEntity<Prisoners> updatePrisoner(@RequestBody Prisoners prisoner){
		return new ResponseEntity<Prisoners>(this.prisonerService.update(prisoner),HttpStatus.OK);
	}

	@DeleteMapping("/delete")
	public ResponseEntity<Prisoners> deletePrisoner(@RequestParam(value="id") Integer id){
		Prisoners prisoner=this.prisonerService.foundById(id);
		if(prisoner==null) {
			return null;
		}
		return new ResponseEntity<Prisoners>(this.prisonerService.delete(prisoner),HttpStatus.OK);
	}
	
	@GetMapping("/getPrisonerByCf")
	public ResponseEntity<Prisoners> getPrisonerByCf(@RequestParam(value="cf")String cf)throws NoResultException{
		
		Prisoners p=this.prisonerService.findByCF(cf);
		if (p==null) {
			p=new Prisoners();
			p.setId(-1);
			return new ResponseEntity<Prisoners>(p,HttpStatus.OK);
		}
		List<Dossier> dossiers=this.dossierService.getAllDossiers();
		System.out.println(dossiers.size());
		for(Dossier d:dossiers) {
			System.out.println(d.getPrisoner().getCF()+" mio:"+cf);
			if(d.getPrisoner().getCF().equals(cf)) {
				System.out.println("trovato il cf");
				p=new Prisoners();
				p.setId(-2);
				return new ResponseEntity<Prisoners>(p,HttpStatus.OK);
			}
		}
		return new ResponseEntity<Prisoners>(p,HttpStatus.OK);
	}



}
