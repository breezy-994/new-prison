package com.example.demo.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
public class Dossier implements Serializable{

	@Override
	public String toString() {
		return "Dossier [id=" + id + ", dataCarcerazione=" + dataCarcerazione + ", dataScarcerazione="
				+ dataScarcerazione + ", crimine=" + crimine + ", prisoner=" + prisoner + ", gard=" + gard + "]";
	}

	private static final long serialVersionUID = -104888884603380339L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private String dataCarcerazione;
	private String dataScarcerazione;
	private String crimine;
	
		
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn
	private Prisoners prisoner;
	
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="id_guard")
	private Guard gard;

	
	
	public Guard getGuard() {
		return this.gard;
	}

	public void setGuard(Guard guard) {
		this.gard = guard;
	}

	public Dossier() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDataCarcerazione() {
		return dataCarcerazione;
	}

	public void setDataCarcerazione(String dataCarcerazione) {
		this.dataCarcerazione = dataCarcerazione;
	}

	public String getDataScarcerazione() {
		return dataScarcerazione;
	}

	public void setDataScarcerazione(String dataScarcerazione) {
		this.dataScarcerazione = dataScarcerazione;
	}

	public String getCrimine() {
		return crimine;
	}

	public void setCrimine(String crimine) {
		this.crimine = crimine;
	}

	public Prisoners getPrisoner() {
		return prisoner;
	}

	public void setPrisoner(Prisoners prisoner) {
		this.prisoner = prisoner;
	}
	
}
