package com.example.demo.repositary;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Dossier;

@Repository
public class DossierRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public Dossier insertDossier(Dossier d) {

		return this.entityManager.merge(d);
	}
	
	@Transactional
	public List<Dossier> allDossiers(){
		Query q=entityManager.createQuery("SELECT u FROM Dossier u");
		return q.getResultList();
	}

	@Transactional
	public Dossier updateDossier(Dossier d) {
		return this.entityManager.merge(d);
	}
	
	@Transactional
	public Dossier deleteDossier(Dossier d) {
		this.entityManager.remove(d);
		flushclear();
		return d;
	}
	
	@Transactional
	public Dossier foundById(Integer id) {
		return this.entityManager.find(Dossier.class,id);
	}
	
	private void flushclear() {
		entityManager.flush();
		entityManager.clear();
	}

	public List<Dossier> ricercaPerCrimine(String crimine) {
		Query query=this.entityManager.createQuery("SELECT d FROM Dossier d WHERE d.crimine='"+crimine+"'");
		return query.getResultList();
	}

	public Dossier ricercaPerPrisonerCf(String cf) {
		Query q=this.entityManager.createQuery("SELECT d FROM Dossier d JOIN d.prisoner p WHERE p.CF='"+cf+"'");
		return (Dossier)q.getSingleResult();
	}
}
