package com.example.demo.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Dossier;
import com.example.demo.entity.Guard;
import com.example.demo.repositary.DossierRepository;

@Service
public class DossierService {

	@Autowired
	private DossierRepository dossierRepository;
	
	public List<Dossier> getAllDossiers(){
		return this.dossierRepository.allDossiers();
	}

	public Dossier inserisci(Dossier dossier) {
		return this.dossierRepository.insertDossier(dossier);
	}
	
	public Dossier update(Dossier dossier) {
		return this.dossierRepository.updateDossier(dossier);
	}
	
	public Dossier delete(Dossier dossier) {
		//dossier.setGuard(null);
		return this.dossierRepository.deleteDossier(/*this.dossierRepository.updateDossier(dossier)*/dossier);
	}
	
	public Dossier foundById(Integer id) {
		return this.dossierRepository.foundById(id);
	}

	public List<Dossier> ricercaPerCrimine(String crimine) {
		return this.dossierRepository.ricercaPerCrimine(crimine);
	}

	public Dossier ricercaPerPrisonerCf(String cf) {
		// TODO Auto-generated method stub
		return this.dossierRepository.ricercaPerPrisonerCf(cf);
	}
		
}
