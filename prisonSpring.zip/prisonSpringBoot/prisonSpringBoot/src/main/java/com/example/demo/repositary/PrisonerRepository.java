package com.example.demo.repositary;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Prisoners;

@Repository
public class PrisonerRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public Prisoners insert(Prisoners g) {
		g=this.entityManager.merge(g);
		flushclear();
		return g;
	}
	
	@Transactional
	public List<Prisoners> allPrisoner(){
		Query q=entityManager.createQuery("SELECT u FROM Prisoners u");
		return q.getResultList();
	}

	@Transactional
	public Prisoners updatePrisoner(Prisoners p) {
		Prisoners prisoner=this.entityManager.merge(p);
		flushclear();
		return prisoner;
	}
	
	@Transactional
	public Prisoners deletePrisoner(Prisoners prisoner) {
		this.entityManager.remove(prisoner);
		return prisoner;
	}
	
	@Transactional
	public Prisoners foundById(Integer id) {
		return this.entityManager.find(Prisoners.class,id);
	}
	
	private void flushclear() {
		entityManager.flush();
		entityManager.clear();
	}

	@Transactional
	public Prisoners foundByCF(String cf) {
		Query q=this.entityManager.createQuery("SELECT p FROM Prisoners p WHERE p.CF='"+cf+"'");
		return (Prisoners) q.getResultList().stream().findFirst().orElse(null);
	}

}
