package com.example.demo.repositary;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Guard;

@Repository
public class GuardRepository {
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public Guard insertGuard(Guard g) {
		entityManager.persist(g);
		flushclear();
		return g;
	}
	
	@Transactional
	public List<Guard> allGuards(){
		Query q=entityManager.createQuery("SELECT u FROM Guard u");
		return q.getResultList();
	}

	@Transactional
	public Guard updateGuard(Guard g) {
		Guard guard=this.entityManager.merge(g);
		flushclear();
		return guard;
	}
	
	@Transactional
	public Guard deleteGuard(Guard guard) {
		this.entityManager.remove(guard);
		flushclear();
		return guard;
	}
	
	@Transactional
	public Guard foundById(Integer id) {
		return this.entityManager.find(Guard.class,id);
	}
	
	private void flushclear() {
		entityManager.flush();
		entityManager.clear();
	}
}
