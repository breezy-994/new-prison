package com.example.demo.dto;

import java.io.Serializable;

public class InfoReportDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6538105347916105055L;

	public InfoReportDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	private Integer numeroGuardie;
	private Integer numDetenuti;
	
	public Integer getNumeroGuardie() {
		return numeroGuardie;
	}
	public void setNumeroGuardie(Integer numeroGuardie) {
		this.numeroGuardie = numeroGuardie;
	}
	public Integer getNumDetenuti() {
		return numDetenuti;
	}
	public void setNumDetenuti(Integer numDetenuti) {
		this.numDetenuti = numDetenuti;
	}

}
