package com.example.demo.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.InfoReportDTO;
import com.example.demo.service.GuardService;
import com.example.demo.service.PrisonerService;

@RestController
@RequestMapping("/report")
@CrossOrigin(origins="http://localhost:4200")
public class ReportController {

	@Autowired
	private GuardService guardService;
	
	@Autowired
	private PrisonerService prisonerService;
	
	@GetMapping
	public ResponseEntity<InfoReportDTO> reportInfo(){
		InfoReportDTO report=new InfoReportDTO();
		report.setNumDetenuti(this.prisonerService.getAllPrisoners().size());
		report.setNumeroGuardie(this.guardService.getAllGuards().size());
		return new ResponseEntity<InfoReportDTO>(report,HttpStatus.OK);
	}
	
}
