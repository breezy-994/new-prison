package com.example.demo.dto;

import com.example.demo.entity.Prisoners;

public class PrisonerDTO {
	private Prisoners prisoner;
	private String esito;
	
	
	
	public PrisonerDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public PrisonerDTO(Prisoners prisoner, String esito) {
		super();
		this.prisoner = prisoner;
		this.esito = esito;
	}


	public Prisoners getPrisoner() {
		return prisoner;
	}
	public void setPrisoner(Prisoners prisoner) {
		this.prisoner = prisoner;
	}
	public String getEsito() {
		return esito;
	}
	public void setEsito(String esito) {
		this.esito = esito;
	}
	
	
}
