package com.example.demo.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="prisoners")
public class Prisoners implements Serializable {
	
	private static final long serialVersionUID = -5503343925775044901L;
	
	@Override
	public String toString() {
		return "Prisoners [id=" + id + ", nome=" + nome + ", cognome=" + cognome + ", CF=" + CF + "]";
	}


	@Id
	@Column(name="id")
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@NotNull(message="{NotNull.Prisoners.id.Validation}")
	private int id;
	@Column(name="nome")
	private String nome;
	@Column(name="cognome")
	private String cognome;
	@Column(name="cf")
	private String CF;
	
	
	@OneToOne(mappedBy="prisoner")
	@JoinColumn
	@JsonIgnore
	private Dossier dossier;

	public Dossier getDossier() {
		return dossier;
	}


	public void setDossier(Dossier dossier) {
		this.dossier = dossier;
	}


	public Prisoners() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Prisoners(int id, String nome, String cognome, String cF) {
		super();
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.CF = cF;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public String getCF() {
		return CF;
	}


	public void setCF(String cF) {
		CF = cF;
	}
	
}
