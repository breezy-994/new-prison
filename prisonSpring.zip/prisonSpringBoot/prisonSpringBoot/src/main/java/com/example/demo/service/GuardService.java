package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Dossier;
import com.example.demo.entity.Guard;
import com.example.demo.entity.Prisoners;
import com.example.demo.repositary.DossierRepository;
import com.example.demo.repositary.GuardRepository;

@Service
public class GuardService {

	@Autowired
	private GuardRepository guardRepository;
	
	@Autowired
	private DossierRepository dossierRepository;
	
	
	public List<Guard> getAllGuards(){
		return this.guardRepository.allGuards();
	}

	public Guard inserisci(Guard guard) {
		return this.guardRepository.insertGuard(guard);
	}
	
	public Guard update(Guard guard) {
		return this.guardRepository.updateGuard(guard);
	}
	
	public Guard delete(Guard guard) {
		return this.guardRepository.deleteGuard(guard);
	}
	
	public Guard foundById(Integer id) {
		return this.guardRepository.foundById(id);
	}
	
	public Guard addDossier(Dossier d) {
		return null;
	}
}
